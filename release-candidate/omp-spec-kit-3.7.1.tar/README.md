# omp-spec-kit

`omp-spec-kit` gives Oh My Pi (OMP) and Claude Code a bounded view of a project's specifications through exactly 9 task-oriented MCP tools: 8 bounded read-only tools (`mcp_preflight`, `spec_catalog`, `spec_entities`, `spec_graph`, `spec_documents`, `spec_inspect`, `spec_tasks`, `spec_markdown`) and one transactional patch tool, `spec_patch`. Only a hash-checked `spec_patch` apply with `dryRun: false` can write specification bytes.

## Install

OMP, at project scope:

```text
omp plugin marketplace add stgmt/omp-spec-kit
omp plugin install omp-spec-kit@omp-spec-kit --scope project
```

Restart OMP in the target project.

Claude Code 2.1.292 or newer:

```text
/plugin marketplace add stgmt/omp-spec-kit
/plugin install omp-spec-kit@omp-spec-kit
/reload-plugins
```

Both hosts read the same payload from the single catalog `.claude-plugin/marketplace.json`. Update an OMP project install with `omp plugin upgrade omp-spec-kit@omp-spec-kit --scope project`, then restart OMP.

## Use

The installed hosts connect to the configured MCP registry. The workspace project record selects the project for each call, and the registry reads its bound specification repository. Query results include provenance for the selected project and corpus.

The payload ships three skills: `spec-inventory` (lists specifications through `spec_catalog`), `spec-elicitation` (source and gap assessment before the first specification write), and `engineering-anti-bike`. The skills are guidance only and implement no scanner or runtime of their own.

In Claude Code, a `PreToolUse` hook blocks direct reads and writes of `.specs`. It is a barrier, not a sandbox: Bash-level checks are regex based.

## Remote mode

The shipped `.mcp.json` declares the registry endpoint, not a local server. Set the environment
before the host starts:

- `OMP_SPEC_REGISTRY_URL` — the registry `/mcp` endpoint (for example `http://127.0.0.1:8650/mcp`)
- `OMP_SPEC_REGISTRY_TOKEN` — the caller's verified YouTrack token

The project is **not** an environment variable and not a header. Each session selects it per MCP
call from its own workspace record, `<workspace>/.omp-spec-kit/project.json`:

```json
{ "schema": "omp-spec-kit/project-binding@1", "project": "owner/project" }
```

Write it once with the installer (`node scripts/install-host.mjs --host <host> --project owner/project
--workspace <dir>`) or by hand, then bind the repository:

```
spec_repo {"action":"bind","project":"owner/project","repoUrl":"<git-url>","token":"<fine-grained-pat-with-contents-rw>"}
```

Switching a session's workspace switches its project on the next call; no restart and no
reconnect are needed, and another session in a different repository keeps its own project. A spec
call in a workspace without a record is refused with `PROJECT_REQUIRED`.

There is no stdio fallback and no local corpus: a host that cannot expand these placeholders does
not connect, which is deliberate. The bundled `dist/mcp/server.js` runs inside the registry image;
it is not a host launch path. `scripts/probe-managed-remote.mjs` proves the managed resolution.

On hosts with a global HTTP proxy, add the endpoint host to `NO_PROXY` (`127.0.0.1,localhost` for a
local stack): the runtime routes HTTP through the proxy otherwise and the connection times out.

## Advisory

v0.3.0 MCP results can use package cwd rather than active project cwd. See [the advisory](../../docs/advisories/v0.3.0-mcp-root.md); current releases are not affected.

License: MIT.
